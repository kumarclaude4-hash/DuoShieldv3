import 'dart:convert';
import 'dart:developer' as developer;
import 'dart:typed_data';

import 'package:bip39/bip39.dart' as bip39;
import 'package:crypto/crypto.dart' as crypto;
import 'package:convert/convert.dart';
import 'package:ed25519_hd_key/ed25519_hd_key.dart';

import '../errors/exceptions.dart';

/// Utility class for all cryptographic key operations in DuoShield.
/// Handles seed phrase generation, key derivation, and key format validation.
class KeyUtils {
  // Prevent instantiation
  const KeyUtils._();

  // BIP44 derivation path for DuoShield identity
  static const String _derivationPath = "m/44'/784'/0'/0'/0'";

  // Ed25519 seed length
  static const int _seedLength = 32;

  /// Generate a new 24-word BIP39 mnemonic seed phrase.
  /// Returns the mnemonic string with words separated by spaces.
  static String generateSeedPhrase() {
    try {
      // Generate 256 bits of entropy -> 24 words
      final mnemonic = bip39.generateMnemonic(strength: 256);
      developer.log('Seed phrase generated (24 words)');
      return mnemonic;
    } catch (e, stackTrace) {
      developer.log('Failed to generate seed phrase: $e');
      throw IdentityException(
        'Failed to generate seed phrase',
        code: 'SEED_GENERATE_FAILED',
        stackTrace: stackTrace,
      );
    }
  }

  /// Validate a BIP39 mnemonic seed phrase.
  /// Returns true if the mnemonic is valid, false otherwise.
  static bool validateSeedPhrase(String mnemonic) {
    try {
      if (mnemonic.trim().isEmpty) {
        return false;
      }
      return bip39.validateMnemonic(mnemonic.trim());
    } catch (e) {
      developer.log('Seed phrase validation error: $e');
      return false;
    }
  }

  /// Convert a mnemonic seed phrase to its entropy bytes.
  /// Used for deterministic key derivation.
  static Uint8List mnemonicToSeed(String mnemonic) {
    try {
      if (!validateSeedPhrase(mnemonic)) {
        throw ValidationException(
          'Invalid mnemonic seed phrase',
          code: 'INVALID_MNEMONIC',
        );
      }
      final seed = bip39.mnemonicToSeed(mnemonic.trim());
      developer.log('Mnemonic converted to seed');
      return seed;
    } on ValidationException {
      rethrow;
    } catch (e, stackTrace) {
      developer.log('Failed to convert mnemonic to seed: $e');
      throw IdentityException(
        'Failed to derive seed from mnemonic',
        code: 'MNEMONIC_TO_SEED_FAILED',
        stackTrace: stackTrace,
      );
    }
  }

  /// Derive an Ed25519 keypair from a mnemonic seed phrase.
  /// Returns a map containing 'privateKey' and 'publicKey' as hex strings.
  static Future<Map<String, String>> deriveKeypair(String mnemonic) async {
    try {
      // Convert mnemonic to BIP39 seed
      final seed = mnemonicToSeed(mnemonic);

      // Derive Ed25519 key using HD path
      final keyData = await ED25519_HD_KEY.derivePath(
        _derivationPath,
        seed,
      );

      // Extract private key (32 bytes)
      final privateKey = keyData.key;

      if (privateKey.length != _seedLength) {
        throw IdentityException(
          'Derived private key has invalid length: ${privateKey.length}',
          code: 'INVALID_KEY_LENGTH',
        );
      }

      // Derive public key from private key using Ed25519
      final publicKey = await _derivePublicKey(privateKey);

      final privateKeyHex = hex.encode(privateKey);
      final publicKeyHex = hex.encode(publicKey);

      developer.log('Keypair derived successfully. Public key: ${publicKeyHex.substring(0, 16)}...');

      return {
        'privateKey': privateKeyHex,
        'publicKey': publicKeyHex,
      };
    } on IdentityException {
      rethrow;
    } catch (e, stackTrace) {
      developer.log('Failed to derive keypair: $e');
      throw IdentityException(
        'Failed to derive identity keypair',
        code: 'KEYPAIR_DERIVATION_FAILED',
        stackTrace: stackTrace,
      );
    }
  }

  /// Derive Ed25519 public key from private key bytes.
  static Future<Uint8List> _derivePublicKey(Uint8List privateKey) async {
    try {
      // Use the ed25519_hd_key package to get the public key
      final master = await ED25519_HD_KEY.getMasterKeyFromSeed(privateKey);
      // The public key is the last 32 bytes of the extended key
      return master.sublist(32, 64);
    } catch (e, stackTrace) {
      developer.log('Failed to derive public key: $e');
      throw IdentityException(
        'Failed to derive public key from private key',
        code: 'PUBLIC_KEY_DERIVATION_FAILED',
        stackTrace: stackTrace,
      );
    }
  }

  /// Validate that a string is a valid hex-encoded public key.
  /// A valid public key is a 64-character hex string (32 bytes).
  static bool isValidPublicKey(String publicKey) {
    if (publicKey.isEmpty) {
      return false;
    }

    // Remove 0x prefix if present
    final cleanKey = publicKey.startsWith('0x') ? publicKey.substring(2) : publicKey;

    // Check length (64 hex chars = 32 bytes)
    if (cleanKey.length != 64) {
      return false;
    }

    // Check all characters are valid hex
    final hexRegex = RegExp(r'^[0-9a-fA-F]+$');
    return hexRegex.hasMatch(cleanKey);
  }

  /// Normalize a public key string to lowercase hex without 0x prefix.
  static String normalizePublicKey(String publicKey) {
    final cleanKey = publicKey.startsWith('0x') ? publicKey.substring(2) : publicKey;
    return cleanKey.toLowerCase();
  }

  /// Hash a public key to create a shorter display identifier.
  static String hashPublicKeyForDisplay(String publicKey) {
    try {
      final normalized = normalizePublicKey(publicKey);
      final bytes = hex.decode(normalized);
      final hash = crypto.sha256.convert(bytes);
      return hex.encode(hash.bytes).substring(0, 16);
    } catch (e) {
      developer.log('Failed to hash public key: $e');
      return publicKey.substring(0, 16);
    }
  }

  /// Convert hex string to bytes.
  static Uint8List hexToBytes(String hexStr) {
    try {
      final clean = hexStr.startsWith('0x') ? hexStr.substring(2) : hexStr;
      return Uint8List.fromList(hex.decode(clean));
    } catch (e, stackTrace) {
      developer.log('Failed to convert hex to bytes: $e');
      throw ValidationException(
        'Invalid hex string: $hexStr',
        code: 'INVALID_HEX',
        stackTrace: stackTrace,
      );
    }
  }

  /// Convert bytes to hex string.
  static String bytesToHex(Uint8List bytes) {
    return hex.encode(bytes);
  }

  /// Generate a SHA-256 hash of the given data.
  static String sha256(String data) {
    final bytes = Uint8List.fromList(utf8.encode(data));
    final hash = crypto.sha256.convert(bytes);
    return hex.encode(hash.bytes);
  }

  /// Generate a random nonce for encryption operations.
  static Uint8List generateNonce(int length) {
    // Note: In production, use a cryptographically secure random number generator
    // The crypto package's Random is secure for this purpose
    final random = crypto.SecureRandom();
    final nonce = Uint8List(length);
    for (var i = 0; i < length; i++) {
      nonce[i] = random.nextInt(256);
    }
    return nonce;
  }
}
