import 'dart:async';
import 'dart:developer' as developer;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'app.dart';
import 'core/constants/app_colors.dart';

// Global background message handler - must be a top-level function
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  developer.log('Background FCM message received: ${message.messageId}');
}

// Initialize local notifications plugin globally for background access
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

// Local notification channel configuration
const AndroidNotificationChannel channel = AndroidNotificationChannel(
  'duoshield_messages', // id
  'DuoShield Messages', // title
  description: 'Secure message notifications for DuoShield',
  importance: Importance.high,
  playSound: true,
  enableVibration: true,
  showBadge: true,
);

Future<void> main() async {
  // Ensure Flutter bindings are initialized
  WidgetsFlutterBinding.ensureInstance();

  // Set preferred orientations
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Set system UI overlay style for dark theme
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
      systemNavigationBarColor: AppColors.background,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // Initialize Firebase
  try {
    await Firebase.initializeApp();
    developer.log('Firebase initialized successfully');
  } catch (e) {
    developer.log('Firebase initialization failed: $e');
    // Continue anyway - app should work in offline mode
  }

  // Set up background message handler for FCM
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // Initialize Hive local database
  await Hive.initFlutter();

  // Register Hive type adapters
  _registerHiveAdapters();

  // Open required Hive boxes
  await _openHiveBoxes();

  // Initialize local notifications
  await _initializeLocalNotifications();

  // Run the app with Riverpod ProviderScope
  runApp(
    const ProviderScope(
      child: DuoShieldApp(),
    ),
  );
}

void _registerHiveAdapters() {
  // Type adapters will be registered here after code generation
  // Hive.registerAdapter(IdentityModelAdapter());
  // Hive.registerAdapter(ContactModelAdapter());
  // Hive.registerAdapter(MessageModelAdapter());
  // Hive.registerAdapter(ConversationModelAdapter());
  // Note: These are registered after generated adapter files are created
  developer.log('Hive adapters registered');
}

Future<void> _openHiveBoxes() async {
  try {
    await Hive.openBox<String>('duoshield_identity');
    await Hive.openBox<Map>('duoshield_contacts');
    await Hive.openBox<Map>('duoshield_messages');
    await Hive.openBox<Map>('duoshield_conversations');
    await Hive.openBox<Map>('duoshield_settings');
    await Hive.openBox<Map>('duoshield_signal_sessions');
    await Hive.openBox<String>('duoshield_plaintext_cache');
    developer.log('All Hive boxes opened successfully');
  } catch (e) {
    developer.log('Error opening Hive boxes: $e');
    rethrow;
  }
}

Future<void> _initializeLocalNotifications() async {
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');

  const DarwinInitializationSettings initializationSettingsIOS =
      DarwinInitializationSettings(
    requestAlertPermission: false,
    requestBadgePermission: false,
    requestSoundPermission: false,
  );

  const InitializationSettings initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
    iOS: initializationSettingsIOS,
  );

  await flutterLocalNotificationsPlugin.initialize(
    initializationSettings,
    onDidReceiveNotificationResponse: _onNotificationTapped,
    onDidReceiveBackgroundNotificationResponse:
        _onBackgroundNotificationTapped,
  );

  // Create Android notification channel
  final AndroidFlutterLocalNotificationsPlugin? androidPlugin =
      flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  await androidPlugin?.createNotificationChannel(channel);

  developer.log('Local notifications initialized');
}

void _onNotificationTapped(NotificationResponse response) {
  developer.log('Notification tapped: ${response.payload}');
}

@pragma('vm:entry-point')
void _onBackgroundNotificationTapped(NotificationResponse response) {
  developer.log('Background notification tapped: ${response.payload}');
}
